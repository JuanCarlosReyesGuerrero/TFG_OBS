<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<title><?php echo $__env->yieldContent('title','default'); ?></title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/bootstrap/css/bootstrap.css')); ?>">
</head>
<body>
	<section>
		<?php echo $__env->yieldContent('content'); ?>
	</section>
</body>
</html>
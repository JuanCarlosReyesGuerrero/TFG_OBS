<?php $__env->startSection('title'); ?> 
    Inicio de mi página
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 
    <h1>Hola esto es un bootstrap</h1>
    <a href="" class="btn btn-success">Soy un boton bootstrap</a>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
@extends('admin.template.main')

@section('title') 
    Inicio de mi página
@endsection

@section('content') 
    <h1>Hola esto es un bootstrap</h1>
    <a href="" class="btn btn-success">Soy un boton bootstrap</a>
@endsection

